
#ifndef _NALOGA1_H
#define _NALOGA1_H

char* zdruzi(char** nizi, char* locilo);

#endif
